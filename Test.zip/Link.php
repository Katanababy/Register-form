<?php 
$link = mysqli_connect("localhost","root","123456789","Test") or die(mysqli_error($link));


?> 